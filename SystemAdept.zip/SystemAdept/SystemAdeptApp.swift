//
//  SystemAdeptApp.swift
//  SystemAdept
//
//  Created by Thomas Akin on 3/29/25.
//

import SwiftUI
import FirebaseCore
import FirebaseFirestore
import FirebaseAuth

@main
struct SystemAdeptApp: App {
  // Initialize Firebase in your App’s init
  init() {
    FirebaseApp.configure()
      
    // Prepare background tasks
    BackgroundTaskManager.shared.scheduleAppRefresh()
      
    // Force-apply appearance for the first time:
    themeManager.applyNavigationBarAppearance()
  }

  @StateObject private var authVM = AuthViewModel()
  @StateObject private var activeSystemsVM = ActiveSystemsViewModel()
  @StateObject private var themeManager = ThemeManager()
  @Environment(\.scenePhase) private var scenePhase
    
  var body: some Scene {
    WindowGroup {
        ZStack {
            GeometryReader { geo in
              Image(themeManager.theme.backgroundImageName)
                .resizable()
                .scaledToFill()
                .frame(width: geo.size.width, height: geo.size.height)
                .clipped()
            }
            .ignoresSafeArea()
            Group {
                if authVM.isLoggedIn {
                    MainTabView()
                        .environmentObject(authVM)
                        .environmentObject(activeSystemsVM)
                        .environmentObject(themeManager)
                } else {
                    AuthView()
                        .environmentObject(authVM)
                }
            }
            .background(Color.clear)
        }
    }
    .onChange(of: scenePhase) { newPhase in
        if newPhase == .active {
            // For every system the user has, run maintenance
            for sys in activeSystemsVM.activeSystems {
                QuestQueueViewModel.runMaintenance(for: sys)
            }
        }
    }
  }
}

