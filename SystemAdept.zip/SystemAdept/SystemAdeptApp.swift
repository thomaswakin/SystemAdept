//
//  SystemAdeptApp.swift
//  SystemAdept
//
//  Created by Thomas Akin on 3/29/25.

import SwiftUI
import FirebaseCore
import BackgroundTasks

@main
struct SystemAdeptApp: App {
    // MARK: - State Objects
    @StateObject private var appState = AppState()
    @StateObject private var authVM = AuthViewModel()
    @StateObject private var activeSystemsVM = ActiveSystemsViewModel()
    @StateObject private var themeManager = ThemeManager()
    @Environment(\ .scenePhase) private var scenePhase
    
    // create a single MyQuestsViewModel to share
    @StateObject private var questsVM = MyQuestsViewModel()

    init() {
        // Configure Firebase
        FirebaseApp.configure()
        // Schedule any background tasks
        BackgroundTaskManager.shared.scheduleAppRefresh()
        // Apply initial bar styles
        themeManager.applyNavigationBarAppearance()
        themeManager.applyTabBarAppearance()

        // Clear UITableView backgrounds for SwiftUI Lists
        UITableView.appearance().backgroundColor = .clear
        UITableViewCell.appearance().backgroundColor = .clear
        
        // we cannot refer to other @StateObjects here, so initialize in-place:
        let asvm = ActiveSystemsViewModel()
        let qvm  = MyQuestsViewModel()
        _activeSystemsVM = StateObject(wrappedValue: asvm)
        _questsVM        = StateObject(wrappedValue: qvm)
        _appState        = StateObject(
              wrappedValue: AppState(activeSystemsVM: asvm, questsVM: qvm)
        )
    }


    var body: some Scene {
      WindowGroup {
        ZStack {
          // 1) Full-screen wallpaper under *all* edges:
          themeManager.theme.backgroundImage
            .resizable()
            .scaledToFill()
            .ignoresSafeArea()

          // 2) Your TabView in its normal safe-area:
          MainTabView()
            .environmentObject(authVM)
            .environmentObject(activeSystemsVM)
            .environmentObject(questsVM)
            .environmentObject(themeManager)
            .environmentObject(appState)
        }
        // ***REMOVE*** these on the ZStack:
        // .scrollContentBackground(.hidden)
        // .toolbarBackground(.hidden)
        // .background(Color.clear)
        // .ignoresSafeArea()
      }
    }
}


