//
//  AppState.swift
//  SystemAdept
//
//  Created by Thomas Akin on 4/26/25.
//


import SwiftUI
import Combine

/// Drives which Tab and which Quests page to show on launch.
final class AppState: ObservableObject {
    enum Tab: Hashable {
        case player, systems, quests
    }
    /// Mirror your MainTabView.Tab
    @Published var selectedTab: Tab = .quests

    /// Mirror your MyQuestsView.Page
    @Published var initialQuestPage: MyQuestsView.Page = .daily

    private var cancellables = Set<AnyCancellable>()

    init(
      activeSystemsVM: ActiveSystemsViewModel,
      questsVM: MyQuestsViewModel
    ) {
        // Whenever activeSystems change, recompute
        activeSystemsVM.$activeSystems
          .combineLatest(questsVM.$activeQuests)
          .receive(on: DispatchQueue.main)
          .sink { systems, quests in
            self.route(systems: systems, quests: quests)
          }
          .store(in: &cancellables)
    }

    private func route(
      systems: [ActiveQuestSystem],
      quests: [ActiveQuest]
    ) {
        // 1) No systems → show Available Systems
        guard !systems.isEmpty else {
          selectedTab = .systems
          return
        }
        // 2) We have systems → goto Quests
        selectedTab = .quests

        // find today's due
        let now = Date()
        let todayInterval = Calendar.current.dateInterval(of: .day, for: now)!
        let dueToday = quests.first {
          $0.progress.status == .available
            && todayInterval.contains($0.progress.expirationTime ?? .distantPast)
        }
        if dueToday != nil {
            initialQuestPage = .daily
            return
        }
        // expired?
        if quests.contains(where: { $0.progress.status == .failed }) {
            initialQuestPage = .expired
            return
        }
        // any other available?
        if quests.contains(where: { $0.progress.status == .available }) {
            initialQuestPage = .active
            return
        }
        // any future unlock?
        if quests.contains(where: { $0.progress.status == .locked }) {
            initialQuestPage = .daily // showing countdown
            return
        }
        // all complete?
        if quests.contains(where: { $0.progress.status == .completed }) {
            initialQuestPage = .complete
            // you could also trigger a pop-up here via another @Published
            return
        }
    }
}